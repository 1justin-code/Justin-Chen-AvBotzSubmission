import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Math.*;
import java.net.URL;

public class Step3 {
	
	static String path = "Files/test.in";
	URL url = getClass().getResource(path);
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException{
		
		ArrayList<Integer> distances = new ArrayList<Integer>();
		int[] coords = new int[3];
		int index = 0;
		Scanner scanner = new Scanner(new File(path));
		  PrintStream out = new PrintStream(new FileOutputStream("Files/test.out"));
		
		while(scanner.hasNextInt())
		{
			coords[index] = scanner.nextInt();
			if(index==2){
				int distance = calculateDistance(coords);
				out.println(distance);
				distances.add(distance);
				index = -1;
				
			}
			index++;
			
		    
		}
		int count =0;
		for(int i=0; i<distances.size(); i++){
			if(distances.get(i)>200){
				count++;
			}
		}
		out.print(count);
		//System.out.println(count);
		
		out.close();
		
		
		
		
		
	}

	private static int calculateDistance(int[] coords) {
		double distance = Math.sqrt((Math.pow((double)coords[0],2)) + (Math.pow((double)coords[1],2)) + (Math.pow((double)coords[2],2)));
		return (int)distance;
		
	}


}
