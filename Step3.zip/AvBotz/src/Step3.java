import java.io.*;
import java.util.Scanner;
import java.lang.Math.*;
import java.net.URL;

public class Step3 {
	
	static String path = "Files/test.in";
	URL url = getClass().getResource(path);
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException{
		
		int[] coords = new int[3];
		int index = 0;
		Scanner scanner = new Scanner(new File(path));
		  PrintStream out = new PrintStream(new FileOutputStream("Files/test.out"));
		
		while(scanner.hasNextInt())
		{
			coords[index] = scanner.nextInt();
			if(index==2){
				int distance = calculateDistance(coords);
				out.println(distance);
				index = -1;
				System.out.println(distance);
				
			}
			index++;
			
		    
		}
		
		out.close();
		
		
		
		
		
	}

	private static int calculateDistance(int[] coords) {
		double distance = Math.sqrt((Math.pow((double)coords[0],2)) + (Math.pow((double)coords[1],2)) + (Math.pow((double)coords[2],2)));
		return (int)distance;
		
	}


}
